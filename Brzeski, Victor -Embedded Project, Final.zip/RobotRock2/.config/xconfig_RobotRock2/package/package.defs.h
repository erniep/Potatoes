/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A44
 */

#ifndef xconfig_RobotRock2__
#define xconfig_RobotRock2__



#endif /* xconfig_RobotRock2__ */ 
