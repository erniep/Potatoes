/*
 * motors.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Wicho
 */
#include "motors.h"

/* Externs */
extern uint8_t follow_flag;

void Board_initMotors(void)
{
	SysCtlPWMClockSet(SYSCTL_PWMDIV_1);														// Set PWM Clock
	SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);												// Enable PWM Module 0
	GPIOPinTypePWM(GPIO_PORTB_BASE, (GPIO_PIN_6|GPIO_PIN_7));								// Set PWM output on PB6, PB7
	GPIOPinConfigure(GPIO_PB6_M0PWM0);														// Configure Pins for PWM use
	GPIOPinConfigure(GPIO_PB7_M0PWM1);
	uint32_t period = (SysCtlClockGet())/switchingfreq - 1;									// Calculate Period
	PWMGenConfigure(PWM0_BASE, PWM_GEN_0, PWM_GEN_MODE_UP_DOWN);							// Configure PWM Generators
	PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0,period);											// Set period of PWM module
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, 0);												// Set Initial DC to 0%
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, 0);
	PWMOutputState(PWM0_BASE, PWM_OUT_0_BIT, true);											// Enable PWM Output
	PWMOutputState(PWM0_BASE, PWM_OUT_1_BIT, true);
	PWMGenEnable(PWM0_BASE, PWM_GEN_0);														// Enable Gen

	// Unlock PD6 and PD7 from Intrinsic NMI Function
	HWREG(GPIO_PORTD_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;
	HWREG(GPIO_PORTD_BASE + GPIO_O_CR) |= 0x80;
	HWREG(GPIO_PORTD_BASE + GPIO_O_AFSEL) &= ~0x80;
	HWREG(GPIO_PORTD_BASE + GPIO_O_DEN) |= 0x80;
	HWREG(GPIO_PORTD_BASE + GPIO_O_LOCK) = 0;

	GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_6 | GPIO_PIN_7);						// Init GPIO Pins
	GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_6 | GPIO_PIN_7);
}
void fw_motors(unsigned int duty)
{
	uint32_t period = PWMGenPeriodGet(PWM0_BASE, PWM_GEN_0);								// Calc new load value and set it on motors
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ((duty * period)/100));
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, ((duty * period)/100));
	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_6 | GPIO_PIN_7),GPIO_PIN_6);					// Set PTC_7, and PTD_6 high, for forward movement
	GPIOPinWrite(GPIO_PORTD_BASE,(GPIO_PIN_6|GPIO_PIN_7),GPIO_PIN_7);
}
void rv_motors(unsigned int duty)
{
	uint32_t period = PWMGenPeriodGet(PWM0_BASE, PWM_GEN_0);								// Get period and calc new load value
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ((duty * period)/100));
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, ((duty * period)/100));
	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_6 | GPIO_PIN_7),GPIO_PIN_7);					// Set PTC_6, and PTD_7 high, for reverse movement
	GPIOPinWrite(GPIO_PORTD_BASE,(GPIO_PIN_6|GPIO_PIN_7),GPIO_PIN_6);
}
void rt_motors(unsigned int duty)
{
	uint32_t period = PWMGenPeriodGet(PWM0_BASE, PWM_GEN_0);								// Get period and load new value for PWM
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ((duty * period)/100));
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, ((duty * period)/100));
	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_6 | GPIO_PIN_7),GPIO_PIN_6);					// Set PTC_7 high, and PTD6 and PTD7 low for right turn
	GPIOPinWrite(GPIO_PORTD_BASE,(GPIO_PIN_6|GPIO_PIN_7),0);
}
void lt_motors(unsigned int duty)
{
	uint32_t period = PWMGenPeriodGet(PWM0_BASE, PWM_GEN_0);								// Get period and load new value for PWM
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ((duty * period)/100));
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, ((duty * period)/100));
	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_6 | GPIO_PIN_7),0);								// Set PTD_6 high, and PTC6 and PTC7 low for right turn
	GPIOPinWrite(GPIO_PORTD_BASE,(GPIO_PIN_6|GPIO_PIN_7),GPIO_PIN_7);
}
void PID_motors(unsigned int dutyright, unsigned int dutyleft)
{
	uint32_t period = PWMGenPeriodGet(PWM0_BASE, PWM_GEN_0);								// Get period and load new value for PWM
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ((dutyright * period)/100));
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, ((dutyleft * period)/100));						// Set PTC_7, and PTD_6 high, for forward movement
	if(dutyleft > brake_thresh)
	{
		GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_6 | GPIO_PIN_7),GPIO_PIN_6);				// Move left motor FWD
	}
	else
	{
		GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_6 | GPIO_PIN_7),0);							// if DC too low, brake
	}
	if(dutyright > brake_thresh)
	{
		GPIOPinWrite(GPIO_PORTD_BASE,(GPIO_PIN_6|GPIO_PIN_7),GPIO_PIN_7);					// Move right motor FWD
	}
	else
	{
		GPIOPinWrite(GPIO_PORTD_BASE,(GPIO_PIN_6|GPIO_PIN_7),0);							// if DC too low, brake
	}
}
void st_motors(unsigned int duty)
{
	PWMGenEnable(PWM0_BASE, PWM_GEN_0);														// Enable PWM generator
	follow_flag = 1;																		// Set line following flag hi
}
