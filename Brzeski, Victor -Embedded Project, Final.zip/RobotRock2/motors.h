/*
 * motors.h
 *
 *  Created on: Nov 26, 2014
 *      Author: Wicho
 */

#ifndef MOTORS_H_
#define MOTORS_H_
/*
 * Library Includes
 */
/* Standard Libraries */
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

/* TivaC Libraries */
#include <driverlib/pwm.h>
#include <driverlib/sysctl.h>
#include <driverlib/gpio.h>
#include <driverlib/pin_map.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <inc/hw_gpio.h>

/* Board libraries */
#include "light_sensor.h"
/*
 * Program Constants
 */
// Switching frequency of Motors
#define switchingfreq 	55
// Threshold of duty cycle that causes motor to brake in PID
#define brake_thresh 	5
//
/*
 * Function prototypes
 */
void Board_initMotors(void);
//*****************************************************************************
//
//! Initializes the Motors for use
//!
//! \param none
//!
//! This function initializes the PWM module 0 for use on two 6V motors mounted
//! on the chassis.
//!
//! \return none
//
//*****************************************************************************
void fw_motors(unsigned int duty);
//*****************************************************************************
//
//! Moves the robot foward
//!
//! \param duty - Intended duty cycle
//!
//! This moves the robot foward at an argument of type duty
//!
//! \return none
//
//*****************************************************************************
void rv_motors(unsigned int duty);
//*****************************************************************************
//
//! Moves the robot in the reverse direction
//!
//! \param duty - Intended duty cycle
//!
//! This moves the robot backwards at an argument of type duty
//!
//! \return none
//
//*****************************************************************************
void rt_motors(unsigned int duty);
//*****************************************************************************
//
//! Moves the robot to the right
//!
//! \param duty - Intended duty cycle
//!
//! This moves the robot to the right at an argument of type duty
//!
//! \return none
//
//*****************************************************************************
void lt_motors(unsigned int duty);
//*****************************************************************************
//
//! Moves the robot to the left
//!
//! \param duty - Intended duty cycle
//!
//! This moves the robot to the left at an argument of type duty
//!
//! \return none
//
//*****************************************************************************
void PID_motors(unsigned int dutyright, unsigned int dutyleft);
//*****************************************************************************
//
//! Adjusts the duty cycle of both motors to follow a line
//!
//! \param dutyright - right motor duty cycle
//! \param dutyleft - left motor duty cycle
//!
//! This function uses PID control to adjust the duty cycle of both motors to
//! allow the robot to follow a black line on white background. This function
//! will be rewritten in the future to use a method named the "Difference"
//! method.
//!
//! \return none
//
//*****************************************************************************
void st_motors(unsigned int duty);
//*****************************************************************************
//
//! Start Motors
//!
//! \param none
//!
//! This function Enables the PWM generator for use, and initializes line following
//!
//! \return none
//
//*****************************************************************************
#endif /* MOTORS_H_ */
