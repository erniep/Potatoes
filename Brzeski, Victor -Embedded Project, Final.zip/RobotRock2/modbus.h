/*
 * modbus.h
 *
 *  Created on: Nov 25, 2014
 *      Author: Wicho
 */

#ifndef MODBUS_H_
#define MODBUS_H_
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>

/* TI-RTOS Header files */
#include <ti/drivers/UART.h>

/* Standard Libraries */
//#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>

/* Example/Board Header files */
#include "Board.h"
#include "motors.h"
#include "light_sensor.h"
/* UART comm frame size constants */
#define SIZEOF_START 		1
#define SIZEOF_FUNCCODE 	2
#define SIZEOF_DLC      	2
#define SIZEOF_CHECKSUM 	2
#define SIZEOF_END      	2
#define MODBUS_DATA_MAX 	10
#define MODBUS_FRAME_MAX 	SIZEOF_START+SIZEOF_FUNCCODE+SIZEOF_DLC+SIZEOF_CHECKSUM+SIZEOF_END+MODBUS_DATA_MAX

/* UART comm error codes */
#define ERROR_NONE      	0
#define ERROR_NOSTART   	1
#define ERROR_CHECKSUM  	2
#define ERROR_NOSTOP    	3
#define ERROR_INVALIDFC 	4

/* UART comm ack codes */
#define ACK_FW          	5
#define ACK_RV				6
#define ACK_RT				7
#define ACK_LT				8
#define ACK_SP				9
#define ACK_ST				10
#define ACK_LS				11
#define ACK_SV				12
/* Structures */
typedef struct {
  char func_code[2];
  void (*func_ptr)(unsigned int);
  uint8_t ack_code;
} cmdintrp;

/* Function Prototypes */
uint8_t getframe(char * framebuf, UART_Handle handle);
//*****************************************************************************
//
//! This function a frame for the UART
//!
//! \param framebuf - Character array buffer
//! \param handle - UART handle to be written to
//!
//! This function grabs a frame that is writting via the UART, it checks the
//! checksum and returns and error if it fails. It also returns an error if
//! no tilda is sent, as well as if no carriage return is sent.
//!
//! \return error code
//
//*****************************************************************************
void ackframe(uint8_t error_code, UART_Handle handle);
//*****************************************************************************
//
//! This function writes an aknowlledgment to the UART specified by the uart handle
//!
//! \param error_code - Error code to be written to data
//! \param handle - UART handle
//!
//! This function writes a frame to the UART with the function code AK, and the
//! data reflecting an error code given by the parameter.
//!
//! \return none
//
//*****************************************************************************
void putframe(char * framebuf, UART_Handle handle);
//*****************************************************************************
//
//! This function writes a frame to the UART
//!
//! \param framebuf - Character array to be sent
//! \param handle - UART handle to be written to
//!
//! This function writes the frame to the UART using UARTwrite function that
//! is part of the TIRTOS library, which uses semaphores to block the task/function
//! until the semaphore is posted, in this situation by the UART interrupt.
//! This function writes the tilda, checksum, and end bits for the user
//!
//! \return none
//
//*****************************************************************************
void int_to_str(uint32_t n, UART_Handle uart);
//*****************************************************************************
//
//! This function writes an integer to the UART
//!
//! \param n - Integer to be written
//! \param handle - UART handle to be written to
//!
//! This function writes an integer to the UART via a recursive function
//!
//! \return none
//
//*****************************************************************************
uint8_t int_to_str2(char * buf, uint32_t n, uint8_t sizebuf);
//*****************************************************************************
//
//! This function converts an integer into a string buffer
//!
//! \param buf - Character array buffer to be written to
//! \param n - Integer to be converted into string
//! \param sizebuf- size of the buffer
//!
//! This function writes the integer specified by parameter n, into buffer buf,
//! and fills the buffer with leading zeros to the point of parameter specified
//! by sizebuf. This string resulted is not null terminated and must be accounted
//! for. Used for Modbus frame management.
//!
//! \returns bytes written of int - doesn't account for null terminator or leading
//! zeroes
//
//*****************************************************************************
uint32_t str_to_int(char * buf, uint8_t sizebuf);
//*****************************************************************************
//
//! This function converts a string into an integer
//!
//! \param buf - Buffer of string
//! \param sizebuf - size of string buffer
//!
//! This function returns an integer represented by the string in the parameter
//! buf, and defined by sizebuf.
//!
//! \return 32-bit int of value specified by string
//
//*****************************************************************************
uint32_t str_checksum(char * buf, uint8_t sizebuf);
//*****************************************************************************
//
//! This function checks the buffer and returns a checksum
//!
//! \param buf - Buffer of data for check
//! \param sizebuf - size of string buffer
//!
//! This function returns an integer value that is the addition of every char
//! int cell by cell and returns that value
//!
//! \return 32-bit checksum of buffer
//
//*****************************************************************************
#endif /* MODBUS_H_ */
