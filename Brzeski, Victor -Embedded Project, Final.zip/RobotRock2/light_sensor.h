/*
 * light_sensor.h
 *
 *  Created on: Nov 16, 2014
 *      Author: Wicho
 */

#ifndef LIGHT_SENSOR_H_
#define LIGHT_SENSOR_H_

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

/* Board Header files */
#include "motors.h"
#include <inc/hw_ints.h>
#include <driverlib/gpio.h>
#include <driverlib/timer.h>
#include <driverlib/interrupt.h>

/* Light Sensor Pin Values */
#define lightsnsr					GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4
#define lightsnsr1					GPIO_PIN_2
#define lightsnsr2					GPIO_PIN_3
#define lightsnsr3					GPIO_PIN_4

/* Threshold values for light sensor */
#define fixedpnt_coffactor 			100
#define fixedpoint_K_coeff 			10
#define fixedpoint_microsec_coeff 	1000000

/* Timer periods */
#define timer2B_prd 				58
#define timer2A_prd 				10

/* State machine black tape length in tics */
#define finish_time 				8
#define record_time 				5
#define record_time2				6

/* State Machine duty cycle references */
#define state1_duty 				50
#define state2_duty					35
#define state3_duty					80

/* State machine States */
#define BEGIN_COURSE				0
#define RECORD_DATA					1
#define FINISH_COURSE				2
/*
 *  PID gain values
 *  fixed point constant of 10
 */

/* Lower and upper limits for Controller */
#define lowerlim 					0
#define upperlim 					85

/* function prototypes */
void lightsense_PID(uint32_t lightsense);
//*****************************************************************************
//
//! Adjusts the duty cycles of the motors according to light sensor feedback
//!
//! \param lightsense - Light sensor readings
//!
//! This function executes a PID algorithm which will adjust the duty cycle of
//! two independent motors, allowing a control of line following. In this
//! function our PID terms have been tuned expirementally due to uncertainty
//! with our models.
//!
//! \return none
//
//*****************************************************************************
int16_t error_calc(uint32_t lightsense);
//*****************************************************************************
//
//! Finds error
//!
//! \param lightsense - Light sensor readings
//!
//! This function returns a 16 bit value that is the error of the light sensor
//! reading. RIght motors are positive, and left motor is negative. U will vary
//!
//! \return error - Error for PID control from light sensor
//
//*****************************************************************************
#endif /* LIGHT_SENSOR_H_ */
