/*
 *
 * modbus.c
 *
 *  Created on: Nov 25, 2014
 *      Author: Wicho
 */
#include "modbus.h"

/* Global variables */
UART_Handle UART1_handle;
char 		framebufferRX[MODBUS_FRAME_MAX];
char 		framebufferTX[MODBUS_FRAME_MAX];
char 		funccodebuf[SIZEOF_FUNCCODE];
char 		databuf[MODBUS_DATA_MAX];
uint8_t 	datalength;
uint8_t 	ack_code;

/* Dispatch Table */
cmdintrp dispatch_table[] = {
/* - function code - function pointer - ACK code */
		{"fw", &fw_motors, ACK_FW},
		{"rv", &rv_motors, ACK_RV},
		{"lt", &lt_motors, ACK_LT},
		{"rt", &rt_motors, ACK_RT},
		{"st", &st_motors, ACK_ST},
		{"sp", &sp_motors, ACK_SP},

};
#define NUM_TABLE_ENTRIES 6
/*
 * Tasks
 */
void RXCmd_Task(void)
{

	UART_Params uartParams;																						// Init UART parameter struct.
    UART_Params_init(&uartParams);																				// Init default UART
    uartParams.writeDataMode = UART_DATA_BINARY;																// Convert to system needs
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.readEcho = UART_ECHO_ON;
    uartParams.baudRate = 115200;
    UART1_handle = UART_open(Board_UART1, &uartParams);															// Open UART0 module
    if (UART1_handle == NULL)																					// Check for opening faulure
    {
    	System_abort("Error opening the UART");
    }
    // Start of task
    while (TRUE)
    {

    	ack_code = getframe(framebufferRX, UART1_handle);													   	// Receive a frame
    	if(ack_code == ERROR_NONE)																				// If no error, proceed
    	{
			// Pend CMD buffer mutex
			Semaphore_pend(Mutex_CMD, BIOS_WAIT_FOREVER);
			memcpy(funccodebuf, framebufferRX, SIZEOF_FUNCCODE);												// Grab function code
			datalength = str_to_int((framebufferRX + SIZEOF_FUNCCODE), SIZEOF_DLC);								// Grab data length code
			memcpy(databuf, (framebufferRX + SIZEOF_FUNCCODE + SIZEOF_DLC), datalength);						// Grab data
			// Post CMD buffer mutex
			Semaphore_post(Mutex_CMD);
			// Post New CMD Semaphore
			Semaphore_post(Sema_CMD);
    	}
    	else Semaphore_post(Sema_TX_ACK);																		// Else, send ACK with error code
    }
}
void TxAck_Task(void)
{
	while(TRUE)
	{
		// Pend on ACK semaphore
		Semaphore_pend(Sema_TX_ACK, BIOS_WAIT_FOREVER);
		// Pend TX mutex
		Semaphore_pend(Mutex_TX, BIOS_WAIT_FOREVER);
		ackframe(ack_code, UART1_handle);																		// Send ACK frame with ACK code
		// Post TX mutex
		Semaphore_post(Mutex_TX);
	}
}
void CmdInt_Task(void)
{
	uint8_t n;
	uint8_t match_flag = 0;
	uint32_t data = 0;
	while(TRUE)
		{
		// Pend on CMD semaphore
		Semaphore_pend(Sema_CMD, BIOS_WAIT_FOREVER);
		// Pend on CMD buffer mutex
		Semaphore_pend(Mutex_CMD, BIOS_WAIT_FOREVER);
		for(n = 0; n<NUM_TABLE_ENTRIES; n++)
		{

			if(!(strcmp(funccodebuf, dispatch_table[n].func_code)))												// Check FC match
			{
				data = str_to_int(databuf, (uint8_t)datalength);												// Convert data to uint
				dispatch_table[n].func_ptr(data);																// Execute Function
				match_flag = 1;																					// Set match flag
				ack_code = dispatch_table[n].ack_code;															// Grab ack code
			}
		}
		if(!match_flag) ack_code = ERROR_INVALIDFC;																// If no FC, return error
		// Post ACK semaphore
		Semaphore_post(Sema_TX_ACK);
		// Post CMD Buffer Mutex
		Semaphore_post(Mutex_CMD);
	}
}
/*
 * Helper Functions
 */
void ackframe(uint8_t error_code, UART_Handle handle)
{
	char data[2];																								// Temporary Data buff for function
	uint8_t size_err = 1;																						// If error code is greater than 10, add one cell to the buff
	if(error_code >= 10) size_err++;																			// Check how many leading zeros are wanted at max
	uint8_t length = int_to_str2(data, error_code, size_err);													// Get Length and store data code into buffer
	char dlc[SIZEOF_DLC];
	int_to_str2(dlc, length, SIZEOF_DLC);																		// Convert DLC into string
	char framebuf[length+SIZEOF_DLC+SIZEOF_FUNCCODE];															// Init frame buffer
	memcpy(framebuf, "ak", SIZEOF_FUNCCODE);
	memcpy(framebuf + SIZEOF_FUNCCODE, dlc, SIZEOF_FUNCCODE);
	memcpy(framebuf + SIZEOF_FUNCCODE + SIZEOF_DLC, data, size_err);
	putframe(framebuf, handle);																					// Put out frame via UART
}
uint8_t getframe(char * framebuf, UART_Handle handle)
{
	char * framebufptr = framebuf;																				// Init temp buffer pointer
	char endbuf[SIZEOF_END];																					// Init frame temp buffers
	UART_read(handle, framebufptr, SIZEOF_START);																// Read in start char
	if(framebufptr[0]!='~') return ERROR_NOSTART;																// Check start char, return error if not '~'
	UART_read(handle, framebufptr, SIZEOF_FUNCCODE);															// Read in function code
	framebufptr += SIZEOF_FUNCCODE;																				// Increment frame pointer
	UART_read(handle, framebufptr, SIZEOF_DLC);																	// Read DLC into framebufptr
	uint32_t dlc = str_to_int(framebufptr, SIZEOF_DLC);															// Convert into int for checksum use
	framebufptr += SIZEOF_DLC;																					// Increment frame pointer
	UART_read(handle, framebufptr, dlc);																		// Get data
	uint32_t checksum_computed = str_checksum(framebufptr, dlc);												// Call checksum function
	framebufptr += dlc;																							// increment point by DLC
	UART_read(handle, framebufptr, SIZEOF_CHECKSUM);															// Read checksum
	uint32_t checksum_frame = str_to_int(framebufptr, SIZEOF_CHECKSUM);											// Convert to integer
	if(checksum_frame != checksum_computed) return ERROR_CHECKSUM;												// if not same, exit and return error
	UART_read(handle, endbuf, SIZEOF_END);																		// Read in end bits
	if(!strcmp(endbuf,"\n\r")) return ERROR_NOSTOP;																// if not \n\r return error
	return ERROR_NONE;																							// If nothing wrong, exit and return no error
}
void putframe(char * framebuf, UART_Handle handle)
{
	char * framebufptr = framebuf;																				// Init temp frame buffer
	UART_write(handle, "~", SIZEOF_START);
	UART_write(handle, framebufptr, SIZEOF_FUNCCODE);															// Write function code
	framebufptr += 2;																							// Inc frame pointer
	UART_write(handle, framebufptr, SIZEOF_DLC);																// Write DLC
	uint32_t dlc = str_to_int(framebufptr, SIZEOF_DLC);															// Convert the STR to an int
	framebufptr += SIZEOF_DLC;																					// Inc framebuf pointer
	UART_write(handle, framebufptr, dlc);																		// Put data out
	uint32_t checksum = str_checksum(framebufptr, dlc);															// Calculate Checksum
	if(checksum<10) UART_write(UART1_handle, "0", 1);															// add a leading zero if the checksum is less than 10
	int_to_str(checksum, UART1_handle);																			// Write checksum to UART
	UART_write(handle, "\n\r", SIZEOF_END);																		// Write end bits
}
uint32_t str_to_int(char * buf, uint8_t sizebuf)
{
	uint8_t n;
	uint32_t result = 0;
	for(n=0; n<sizebuf; n++)
	{
		result = result * 10 + ( buf[n] - '0' );																// Recursively adds lowest char to number after accounting for next multiple
	}
	return result;
}
void int_to_str(uint32_t n, UART_Handle uart)
{
	if(n>=10)
	{
		// Recursive function call
		int_to_str(n/10, uart);
		n = n % 10;																								// Check LSB
	}
	char buf = (char)n + '0';
	UART_write(uart, &buf, 1);																					// print characters
}
uint8_t int_to_str2(char * buf, uint32_t n, uint8_t sizebuf)
{
	uint8_t i;
	char tempbuf[sizebuf];
	for(i = 0; i < sizebuf; i++)																				// Fill buffer with asci zeros
	{
		buf[i] = '0';
	}
	uint8_t length = sprintf(tempbuf, "%d", n);																	// Convert n into string without leading zeros, and null terminator
	memcpy(&buf[sizebuf-length], tempbuf, length);																// Copy string into buffer, also ridding of null terminator
	return length;																								// Returns length of the integer to char array conversion
}
uint32_t str_checksum(char * buf, uint8_t sizebuf)
{
	uint8_t n;
	uint32_t result = 0;
	for(n=0; n<sizebuf; n++)
	{
		result += ((uint32_t)buf[n] - '0');																		// Convert to int, cell by cell, and sum together
	}
	return result;
}

