/*
 * ultrasonic_sensor.c
 *
 *  Created on: Nov 17, 2014
 *      Author: Wicho
 */
#include "ultrasonic_sensor.h"

/* Global Variables */
uint32_t delta_count = 0;
char * pingpongbufptr;
uint8_t data_arr[filter_num_samples];
uint8_t data_sort[filter_num_samples];

/* Externs */
extern UART_Handle UART1_handle;
extern uint8_t data_flag;


void ultrasonic_sensor_task(void)
{
	uint8_t index = 0;
	uint8_t pingpong = 0;
	uint8_t initialbuf_flag = 1;
	char pingbuf[DATA_BUF_SIZE];
	char pongbuf[DATA_BUF_SIZE];

	SysCtlPeripheralEnable(SYSCTL_PERIPH_WTIMER0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
	TimerClockSourceSet(WTIMER0_BASE, TIMER_CLOCK_SYSTEM);
	TimerClockSourceSet(TIMER3_BASE, TIMER_CLOCK_SYSTEM);
	GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE,trig_pin);
	GPIOPinWrite(GPIO_PORTB_BASE, trig_pin, 0);
	TimerConfigure(TIMER3_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_A_ONE_SHOT_UP);			// Timer 3A - One shot
	uint32_t Period = ((SysCtlClockGet() * pulse_length) / fixedpoint_microsec_coeff);		// Set period for Timer3A
	TimerLoadSet(TIMER3_BASE, TIMER_A, (uint16_t)Period -1);								//Enable Interrupt for Timer3A
	TimerIntEnable(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
	IntEnable(INT_TIMER3A);
	GPIOPinTypeTimer(GPIO_PORTC_BASE,echo_pin);												// Timer 0B - Wider timer - Input Capture
	GPIOPinConfigure(GPIO_PC5_WT0CCP1);
	TimerConfigure(WTIMER0_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_CAP_TIME_UP);
	TimerControlEvent(WTIMER0_BASE, TIMER_B, TIMER_EVENT_BOTH_EDGES);						// Interupt on both edges
	TimerIntEnable(WTIMER0_BASE, TIMER_CAPB_EVENT);											// Enable Interrupts for WideTimer0B
	IntEnable(INT_WTIMER0B);

	// Calculate saturated count values
/*
 * Start of task loop
 */
	while(TRUE)
	{
		// Pend on semaphore - Sample frequency
		Semaphore_pend(Sema_ultrasonic_samplefreq, BIOS_WAIT_FOREVER);
		// Send control pulse to dist sensor
		sendpulse();
		// Pend on response from sensor
		Semaphore_pend(Sema_ultrasonic, BIOS_WAIT_FOREVER);
		uint32_t dist_in = count_to_in(delta_count);
		if(dist_in > MAX_DIST) dist_in = MAX_DIST;												// Bound distance
		data_arr[4] = data_arr[3];																// Fill buffer for median filter
		data_arr[3] = data_arr[2];
		data_arr[2] = data_arr[1];
		data_arr[1] = data_arr[0];
		data_arr[0] = (uint8_t)dist_in;
		if(initialbuf_flag && data_arr[3]) initialbuf_flag = 0;									// Fill buffer until 2nd to last cell is filled for transient
		else																					// Once filled, Put/Filter data onto the UART
		{
			memcpy(data_sort, data_arr, filter_num_samples);									// Copy data into array
			sort_arr(data_sort); 																// Sort Array for median filter
			// Ping
			if(!pingpong) pingbuf[index] = data_sort[filter_num_samples/2]; 					//Grab median value
			// Pong
			else pongbuf[index] = data_sort[filter_num_samples/2]; 								//Grab median value
			index++;
			if(index == DATA_BUF_SIZE)															// Check for full buffer
			{
				index = 0;																		// Reset index
				if(!pingpong) pingpongbufptr = pingbuf;											// if on ping, Set pointer to ping buffer
				else pingpongbufptr = pongbuf;													// else, set pointer to pong buffer
				pingpong ^= 1;																	// Toggle Buffers
				// Post data ready sema
				Semaphore_post(Sema_TX_Data);
			}
		}
	}
}
void ultrasonic_CLK(void)
{
	if(data_flag) Semaphore_post(Sema_ultrasonic_samplefreq);									// Post semaphore at one clock ticks if its ready
}
void interrupt timerpulse_ISR(void)
{
	TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);												// Clear IRQ
	GPIOPinWrite(GPIO_PORTB_BASE, trig_pin, 0);													// Set Trigger pin low

}
void ultrasonic_ISR(void)
{

	TimerIntClear(WTIMER0_BASE, TIMER_CAPB_EVENT);												// Clear the timer interrupt
	static uint32_t WTCOUNT1_B = 0;
	uint32_t status = (GPIOPinRead(GPIO_PORTC_BASE,echo_pin) & echo_pin);						// Get pin status and init count values
	if(status)
	{
		WTCOUNT1_B = HWREG(WTIMER0_BASE + TIMER_O_TBR);											// Store the first count value on rising edge
	}
	if(!status)
	{
		delta_count = HWREG(WTIMER0_BASE + TIMER_O_TBR)-WTCOUNT1_B;								// Find change in counts per system clock
		// Post data ready sema
		Semaphore_post(Sema_ultrasonic);
	}
}
uint32_t count_to_cm(uint32_t count)
{
	//	Dynamically assign fixed point values to minimize error
	uint8_t fixedpnt_coeff2 = 1;
	uint32_t fixedpnt_coeff1 = fixedpoint_microsec_coeff;
	uint32_t dist_cm = count/58;
	while((fixedpnt_coeff1 > 0) && (dist_cm > (UINT32_MAX / fixedpnt_coeff1)))
	{

		fixedpnt_coeff2++;																		//Increment coefficient 2
		fixedpnt_coeff1 = fixedpoint_microsec_coeff/fixedpnt_coeff2;							// Divide coefficient 1 by the new value
	}
	dist_cm = ((dist_cm * fixedpnt_coeff1) / SysCtlClockGet()) * fixedpnt_coeff2;
	return dist_cm;																				// Conversion from time to cm
}
uint32_t count_to_in(uint32_t count)
{
	//	Dynamically assign fixed point values to minimize error
	uint8_t fixedpnt_coeff2 = 1;
	uint32_t fixedpnt_coeff1 = fixedpoint_microsec_coeff;
	uint32_t dist_in = count / 148;
	while((fixedpnt_coeff1 > 0) && (dist_in > (UINT32_MAX / fixedpnt_coeff1)))
		{

			fixedpnt_coeff2++;																	//Increment coefficient 2
			fixedpnt_coeff1 = fixedpoint_microsec_coeff/fixedpnt_coeff2;						// Divide coefficient 1 by the new value
		}
		dist_in = ((dist_in * fixedpnt_coeff1) / SysCtlClockGet()) * fixedpnt_coeff2;
		return dist_in;																			// Conversion from time to in
}
void sort_arr(uint8_t * arr)
{
	uint8_t i;
	uint8_t j;
	uint8_t temp;
    for(i=0;i<filter_num_samples;i++)															// Nested for loop to fill sample buffer with ascending values
    {
        for(j=i;j<filter_num_samples;j++)														// start filling cell
        {
            if(arr[i] > arr[j])																	// If one is larger, set that cell to that value, and move on
            {
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }
    }
}
void sendpulse(void)
{
	GPIOPinWrite(GPIO_PORTB_BASE, trig_pin, trig_pin);											// Set trig pin hi
	TimerEnable(TIMER3_BASE, TIMER_A);															// Enable trig Timer
	TimerEnable(WTIMER0_BASE, TIMER_B);															// Enable echo Timer
}
