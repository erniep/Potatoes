/*
 * TXData.h
 *
 *  Created on: Dec 3, 2014
 *      Author: Wicho
 */
#ifndef TXDATA_H_
#define TXDATA_H_
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

/* Board Header Files */
#include "modbus.h"
#include "ultrasonic_sensor.h"
/*
 * Function Prototypes
 */
void TxData_putframe(char * data, UART_Handle uart_handle);
//*****************************************************************************
//
//! Sends a frame on UART with data from ultrasonic sensor
//!
//! \param data - data to be sent from pingpong buffer ptr
//! \param uart_handle - uart handle to send frame on
//!
//! This function sends a frame on the UART with the data in the data pointer.
//! it converts the unsigned int 8 bit data buf to a character buffer to be sent
//! on the UART, with the function code "TX" and a constant data length code of
//! 10. This is due to the nature of the ping pong buffers and the limits of our
//! modbus protocol
//!
//! \return none
//
//*****************************************************************************
#endif /* TXDATA_H_ */
