/*
 * ultrasonic_sensor.h
 *
 *  Created on: Nov 17, 2014
 *      Author: Wicho
 */

#ifndef ULTRASONIC_SENSOR_H_
#define ULTRASONIC_SENSOR_H_

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>

/* Board Header Files */
#include "modbus.h"

/* TI headers */
#include <stdint.h>
#include <stdbool.h>
#include <inc/hw_ints.h>
#include <inc/hw_memmap.h>
#include <inc/hw_timer.h>
#include <inc/hw_sysctl.h>
#include <inc/hw_types.h>
#include <inc/hw_gpio.h>
#include <driverlib/timer.h>
#include <driverlib/interrupt.h>
#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>
#include <driverlib/pin_map.h>

/* GPIO pin defines */
#define trig_pin 	 					GPIO_PIN_4
#define echo_pin 					 	GPIO_PIN_5

/* Fixed Point Coefficients */
#define fixedpoint_microsec_coeff 		1000000
#define fixedpoint_milisec_coeff  		1000

/* Timer Periods */
#define timer_prd 	 					1 //miliseconds
#define pulse_length 					10 //microseconds

/* Buffer size */
#define DATA_BUF_SIZE					5

/* Max sensor reading */
#define MAX_DIST						12

/* Data filter number of samples */
#define filter_num_samples 				5
/*
 * function prototypes
 */
void sendpulse(void);
//*****************************************************************************
//
//! Sends a pulse along the trigger GPIO pin
//!
//! \param none
//!
//! This function triggers a pulse by initializing a timer to interrupt after 10
//! microseconds allowing the toggling on a pin, effectively making a 10us pulse
//! This is used to trigger measurement of the distance sensor
//!
//! \return none
//
//*****************************************************************************
void ultrasonic_init(void);
//*****************************************************************************
//
//! Initialized the robot for ultrasonic sensors
//!
//! \param none
//!
//! This function initializes the robot to use the ultrasonic sensors via the
//! TM4C's built in timer input capture and GPIO pins. Once initialized...
//! the user can run a task which will allow use of the peripheral
//!
//! \return none
//
//*****************************************************************************
uint32_t count_to_cm(uint32_t count);
//*****************************************************************************
//
//! Converts a count value into a cm value
//!
//! \param uint32 count - count value to be converted
//!
//! This function converts the count, a 32 bit value, into a tanglible distance
//! in cm. This function, due to previous problems with errors, dynamically
//! chooses the fixed point coefficients, allowing for optimal conversion
//! with potentially no overflow errors. This dynamic conversion checks if
//! at one point if the product of two numbers exceed the highers allotable
//! value for a 32 bit integer, and changes the coefficients accordingly.
//! The check is only needed at that point in the conversion as prior to
//! the conversion the integers are small.
//!
//! \return distance in cm
//
//*****************************************************************************
uint32_t count_to_in(uint32_t count);
//*****************************************************************************
//
//! Converts a count value into a in value
//!
//! \param uint32 count - count value to be converted
//!
//! This function converts the count, a 32 bit value, into a tanglible distance
//! in in. This function, due to previous problems with errors, dynamically
//! chooses the fixed point coefficients, allowing for optimal conversion
//! with potentially no overflow errors. This dynamic conversion checks if
//! at one point if the product of two numbers exceed the highers allotable
//! value for a 32 bit integer, and changes the coefficients accordingly.
//! The check is only needed at that point in the conversion as prior to
//! the conversion the integers are small.
//!
//! \return distance in in
//
//*****************************************************************************
void sort_arr(uint8_t * arrayptr);
//*****************************************************************************
//
//! Sorts an array of size 3 into ascending order
//!
//! \param uint8_t * arrptr - array pointer
//!
//! This function uses nested for loops to sort an array of size 3 into ascending
//! order. This is used exclusively by the median filter
//!
//! \return none
//
//*****************************************************************************
#endif /* ULTRASONIC_SENSOR_H_ */
