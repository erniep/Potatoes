/*
 * light_sensor.c
 *
 *  Created on: Nov 3, 2014
 *      Author: Wicho
 */
#include "light_sensor.h"
#include "modbus.h"
/* Global variables for light sensor */
int32_t u = 0;																											// Output of controller
uint32_t lightsnsr_val = 0;																								// Light sensor readings
uint8_t data_flag = 0;																									// Flag to enable recording data
uint8_t follow_flag = 0;																								// Flag for posting follow sema
uint8_t dutyref = 0;																									// Motor duty cycle reference

/* Externs */
extern UART_Handle UART1_handle;																						// Uart handle

// Initial Controller gains
uint16_t KP = 70;
uint16_t KI = 12;
uint16_t KD = 500;

void lightsense_task(void)
{
	static uint8_t blk_count = 0;																						// Counter for conescutive black states
	static uint8_t state = 0;																							// State machine counter
	static uint8_t motors_on = 1;																						// Flag for motor task

	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER2);																		// Enable Timer clock source
	TimerClockSourceSet(TIMER2_BASE, TIMER_CLOCK_SYSTEM);																// Set Timer clock source
	TimerConfigure(TIMER2_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_A_ONE_SHOT_UP | TIMER_CFG_B_ONE_SHOT_UP);				// Configure Timer2 as two 16 bit timers
	uint32_t Period = ((SysCtlClockGet() * timer2A_prd) / fixedpoint_microsec_coeff);									// set periods
	TimerLoadSet(TIMER2_BASE, TIMER_A, (uint16_t)Period -1);
	Period = ((SysCtlClockGet() * timer2B_prd) / fixedpoint_microsec_coeff);
	TimerLoadSet(TIMER2_BASE, TIMER_B, (uint16_t)Period -1);															// Enable interrupts for Timer2A and Timer2B
	IntEnable(INT_TIMER2A);
	IntEnable(INT_TIMER2B);
	TimerIntEnable(TIMER2_BASE, TIMER_TIMA_TIMEOUT | TIMER_TIMB_TIMEOUT);

	while(motors_on)
	{
		// Pend on semaphore - Sample frequency
		Semaphore_pend(Sema_lightsense_samplefreq, BIOS_WAIT_FOREVER);
		GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, lightsnsr);																// Set GPIO light sensor to output
		GPIOPinWrite(GPIO_PORTA_BASE, lightsnsr, lightsnsr);															// Set hi to charge caps on sensor
		TimerEnable(TIMER2_BASE, TIMER_A);																				// Enable Timer2A
		// Pend on semaphore
		Semaphore_pend(Sema_lightsense, BIOS_WAIT_FOREVER);
		dutyref = state1_duty;																							// Set duty ref for first section of course
		switch(state)																									// State machine
		{
		case BEGIN_COURSE:
			// Call Motor PID
			lightsense_PID(lightsnsr_val);
			if(lightsnsr_val == 0x7)																					// Check if sensor black
			{
				blk_count++;																							// Inc black counter
				if(blk_count >= record_time)
				{
			        GPIO_toggle(Board_LED2);																			// Turn on red led
					data_flag = 1;																						// Enable recording of data
					state++;																							// Change states for [z+1]
					blk_count = 0;																						// Reset black counter
					KP = 50;																							// Change PID values for next state
					KI = 8;
					KD = 250;

					dutyref = state2_duty;																				// Change duty reference for next state
				}
			}
			else blk_count = 0;																							// If not black, reset counter
			break;
		case RECORD_DATA:																								//Set dutyref
			lightsense_PID(lightsnsr_val);																				// Call Motor PID
			if(lightsnsr_val == 0x7)
			{
				blk_count++;
				if(blk_count == record_time2)
				{
					GPIO_toggle(Board_LED2);
			        GPIO_toggle(Board_LED1);																			// Turn LED Green
					data_flag = 0;																						// Stop collecting data
					putframe("sd010", UART1_handle);																	//Send a stop data frame to computer
					state++;																							// Change state
					blk_count = 0;
					KP = 90;																							// Adjust PID gains
					KI = 8;
					KD = 500;
					dutyref = state3_duty;																				// Set dutyref for final state
				}
			}
			else blk_count = 0;
			break;
		case FINISH_COURSE:


			// Call Motor PID
			lightsense_PID(lightsnsr_val);
			if(lightsnsr_val == 0x7)
			{
				blk_count++;
				if(blk_count == finish_time)
				{

					PID_motors(0,0);																					// Stop motors
					GPIO_toggle(Board_LED1);
			        GPIO_toggle(Board_LED0);																			// Turn LED blue
			        // Exit lightsense task on next sample
			        motors_on = 0;
			        follow_flag = 0;
				}
			}
			else blk_count = 0;
			break;
		}
	}
}
void lightsense_CLK(void)
{
	if(follow_flag) Semaphore_post(Sema_lightsense_samplefreq);															// Post sema if needed
}
void timer2A_ISR(void)
{

	TimerIntClear(TIMER2_BASE, TIMER_TIMA_TIMEOUT);																		// Clear interrupt
	GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, lightsnsr);																	// Set pins to input
	TimerEnable(TIMER2_BASE, TIMER_B);																					// Enable Timer 2B
}
void timer2B_ISR(void)
{
	TimerIntClear(TIMER2_BASE, TIMER_TIMB_TIMEOUT);																		// Clear interrupt
	lightsnsr_val = GPIOPinRead(GPIO_PORTA_BASE, lightsnsr) >> 2;														// Read light sensor
	Semaphore_post(Sema_lightsense);																					// Post data rdy Semaphore
}
void lightsense_PID(uint32_t lightsense)
{
	static int16_t error0 = 0;																							// e[z]
	static int16_t error1 = 0;																							// e[z-1]
	static int16_t error2 = 0;																							// e[z-2]
	static int16_t error3 = 0;																							// e[z-3]
	static int32_t P = 0;
	static int32_t I = 0;
	static int32_t D = 0;

	error3 = error2;																									// Update error values
	error2 = error1;
	error1 = error0;
	error0 = error_calc(lightsense);																					// Calculate error
	P = (KP * error0 / fixedpoint_K_coeff);
	I = I + ((I * error0) / fixedpoint_K_coeff);
	D = ((KD * (error0 + 3*error1 - 3*error2 - error3) / 6) / fixedpoint_K_coeff);
	u = P + I + D;																										// Find U
	int32_t rightDC = dutyref - u;																						// Bound U within limits
	int32_t leftDC = dutyref + u;
	if(rightDC > upperlim) rightDC = upperlim;
	if(leftDC > upperlim) leftDC = upperlim;
	if(rightDC < lowerlim) rightDC = lowerlim;
	if(leftDC < lowerlim) leftDC = lowerlim;

	PID_motors((unsigned int)rightDC,(unsigned int)leftDC);																// Set motor duty cycles
}
int16_t error_calc(uint32_t lightsense)
{
	static int8_t flag = 0;
	switch(lightsense)
	{
	case 0x7:
		return 0;
	case 0x6:
		flag = 1;
		return 1;
	case 0x5:
		return 0;
	case 0x4:
		flag = 1;
		return 3;
	case 0x3:
		flag = 0;
		return -1;
	case 0x2:
		return 0;
	case 0x1:
		flag = 0;
		return -3;
	case 0x0:
		if(flag)
		{
			flag = 1;
			return 5;
		}
		else
		{
			flag = 0;
			return -5;
		}
	}
	return 0;
}
/*
 * Alt Method to consider:
 * Results show instability due to course expectations, specifically horizontal
 * tape measure, however very stable. Would be very powerful for senior design.
 * http://portal.ku.edu.tr/~cbasdogan/Courses/Robotics/projects/Discrete_PID.pdf
 */

