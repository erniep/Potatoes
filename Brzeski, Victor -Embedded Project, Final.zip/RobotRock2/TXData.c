/*
 * TXData.c
 *
 *  Created on: Dec 3, 2014
 *      Author: Wicho
 */
#include "TXData.h"

/* Externs */
extern char * pingpongbufptr;
extern UART_Handle UART1_handle;

void TxData_task(void)
{
	while(TRUE)
	{
		// Pend on semaphore - TX data ready
		Semaphore_pend(Sema_TX_Data, BIOS_WAIT_FOREVER);
		// Pend on Mutex - TX request
		Semaphore_pend(Mutex_TX, BIOS_WAIT_FOREVER);
		TxData_putframe(pingpongbufptr, UART1_handle);						// Write frame
		// Post Mutex - TX done
		Semaphore_post(Mutex_TX);
	}
}
void TxData_putframe(char * data, UART_Handle uart_handle)
{
	uint8_t length = 2 * DATA_BUF_SIZE;										// Init data string buffer for frame
	char dlcbuf[SIZEOF_DLC];												// Init DLC buffer
	char databuf[length];													// init data buffer
	char framebuf[length+SIZEOF_DLC+SIZEOF_FUNCCODE];						// Init frame buffer
	uint8_t index = 0;
	for(index; index < DATA_BUF_SIZE; index++)								// Convert integer into a string for modbus frame
	{
		int_to_str2((databuf + (2 * index)), data[index], 2);				// Grabs data in sets of 2 asci chars, and converts to strings
	}
	int_to_str2(dlcbuf,length,SIZEOF_DLC);									// Converts DLC to string for frame
	memcpy(framebuf, "tx", SIZEOF_FUNCCODE);								// Copy all to one buffer
	memcpy(framebuf + SIZEOF_FUNCCODE, dlcbuf, SIZEOF_DLC);
	memcpy(framebuf + SIZEOF_FUNCCODE + SIZEOF_DLC, databuf, length);
	putframe(framebuf, uart_handle);										// Bon voyage frame - Goes to UART
}


